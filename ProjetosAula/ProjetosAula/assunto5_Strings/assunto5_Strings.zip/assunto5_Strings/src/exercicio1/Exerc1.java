package exercicio1;

public class Exerc1 {

	public static void main(String[] args) {
		String str1 = "linguagem ";
		String str2 = "JAVA";
		str1 = str1.concat(str2);
		System.out.println(str1);
		int qtd = str1.length();
		System.out.println("Quantidade de caracteres da str1: " + qtd);

	}

}
