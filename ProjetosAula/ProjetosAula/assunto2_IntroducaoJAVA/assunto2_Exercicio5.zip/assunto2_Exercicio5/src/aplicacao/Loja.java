package aplicacao;

import java.util.Scanner;

public class Loja {

	public static void main(String[] args) {
		Scanner le = new Scanner(System.in);
		double valorCompra;
		int parcelas;
		int resp = 1;
		while (resp == 1) {
			System.out.print("Valor da compra: R$");
			valorCompra = le.nextDouble();
			do {
				System.out.print("Informe numero de parcelas (1 a 6): ");
				parcelas = le.nextInt();
			} while(parcelas<1 || parcelas>6);
			double precoFinal = 0;
			if (parcelas == 1) {
				precoFinal = valorCompra * 0.9;
			} else if (parcelas <= 3) {
				precoFinal = valorCompra;
			} else if (parcelas == 4) {
				precoFinal = valorCompra * 1.05;
			} else if (parcelas == 5) {
				precoFinal = valorCompra * 1.06;
			} else if (parcelas == 6) {
				precoFinal = valorCompra * 1.08;
			}
			
			if (parcelas >= 1 && parcelas <= 6)
				System.out.println("O preco final da compra: R$" + precoFinal);
			else
				System.out.println("Quantidade de parcelas nao adequada");
			System.out.print("Ha mais 1 cliente? (1-sim 0-nao) :");
			resp = le.nextInt();
		}
		System.out.println("Lojinha fechada!");
		le.close();

	}

}
