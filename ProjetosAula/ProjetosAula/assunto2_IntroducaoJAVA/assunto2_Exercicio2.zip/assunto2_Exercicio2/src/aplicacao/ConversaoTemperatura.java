package aplicacao;

import java.util.Scanner;

public class ConversaoTemperatura {

	public static void main(String[] args) {
		Scanner le = new Scanner(System.in);
		double farenheit, celsius;
		System.out.println("informe tempratura em farenheit: ");
		farenheit = le.nextDouble();
		celsius = (double) 5/9 * (farenheit -32);
		System.out.println("Em centigrados = " + celsius);
		le.close();

	}

}
