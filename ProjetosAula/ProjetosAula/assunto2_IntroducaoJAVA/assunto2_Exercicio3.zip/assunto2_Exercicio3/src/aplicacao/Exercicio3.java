package aplicacao;

import java.util.Scanner;

public class Exercicio3 {

	public static void main(String[] args) {
		Scanner le = new Scanner(System.in);
		System.out.print("Qual o valor da compra? R$");
		double compra = le.nextDouble();
		le.close();
		System.out.print("Informe forma de pagamento 1 a 6 parcelas: ");
		int parcelas = le.nextInt();
		
		double valorFinal = -1;
		if (parcelas == 1) {
			valorFinal = compra * 0.9;
		}
		else if (parcelas <=3) {
			valorFinal = compra;
		}
		else if (parcelas == 4) {
			valorFinal = compra * 1.05;
		}
		else if (parcelas == 5) {
			valorFinal = compra * 1.06;
		}
		else if (parcelas == 6) {
			valorFinal = compra * 1.08;
		}
		System.out.println("Valor a ser pago = R$"+ valorFinal);
		
	}

}
