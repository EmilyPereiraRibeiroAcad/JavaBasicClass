package aplicacao;

public class TabelaTemperatura {

	public static void main(String[] args) {

		int farenheit;
		double celsius;
		for (farenheit = 100; farenheit <= 150; farenheit++) {
			celsius = (double) 5 / 9 * (farenheit - 32);
			// System.out.println("farenheit: "+ farenheit+ "\t celsius: "+ celsius);
			System.out.printf("%s%d%s%.1f\n", "farenheit: ", farenheit, "\t celsius: ", celsius);
		}

	}

}
