package exemplo1Alocacao;

import java.util.Scanner;

public class Exemplo1 {

	public static class Elemento{
		int idade;
	}
	public static void main(String[] args) {
	Scanner le = new Scanner(System.in);
	Elemento p1 = new Elemento();
	Elemento p2 = new Elemento();
	Elemento p3 = new Elemento();

	System.out.println("Informe idades de 3 pessoas");
	System.out.print("Pessoa 1: ");
	p1.idade = le.nextInt();
	System.out.print("Pessoa 2: ");
	p2.idade = le.nextInt();
	System.out.print("Pessoa 3: ");
	p3.idade = le.nextInt();
	System.out.println(p1.idade);
	System.out.println(p2.idade);
	System.out.println(p3.idade);

	le.close();
	}
}
