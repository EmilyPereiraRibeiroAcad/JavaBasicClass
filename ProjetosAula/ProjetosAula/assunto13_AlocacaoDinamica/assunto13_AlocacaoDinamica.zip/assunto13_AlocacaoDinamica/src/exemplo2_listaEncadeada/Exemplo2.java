package exemplo2_listaEncadeada;

public class Exemplo2 {
	
	public static class NO{
		int dado;
		NO prox;
	}

	public static void main(String[] args) {
		NO p1 = new NO();
		p1.dado = 1;
		
		
		NO p2 = new NO();
		p2.dado = 2;
		
		NO p3 = new NO();
		p3.dado = 3;

		p1.prox = p2;
		p2.prox = p3;
		p3.prox = null;
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		
		System.out.println("Dado apontado por p1: "+p1.dado);
		System.out.println("Prox de p1:" + p1.prox);
		System.out.println("Dado apontado por p2: "+p2.dado);
		System.out.println("Prox de p2:" + p2.prox);
		System.out.println("Dado apontado por p3: "+p3.dado);
		System.out.println("Prox de p3:" + p3.prox);
	}

}
