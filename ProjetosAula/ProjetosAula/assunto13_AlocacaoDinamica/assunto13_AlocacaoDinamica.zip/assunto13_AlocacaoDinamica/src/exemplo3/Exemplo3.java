package exemplo3;

import java.util.Scanner;

public class Exemplo3 {
	public class Exemplo1 {

		public static class NO {
			int dado;
			NO prox;
		}

		public static void main(String[] args) {
			Scanner le = new Scanner(System.in);
			NO lista = new NO();

			// Primeiro NÓ
			System.out.print("Informe dado: ");
			lista.dado = le.nextInt();
			lista.prox = null;

			System.out.println("lista:  "+ lista);
			System.out.println("\t dado:"+lista.dado);
			// Segundo NÓ
			NO novo = new NO();
			System.out.print("Informe dado: ");
			novo.dado = le.nextInt();
			novo.prox = null;
			System.out.println("novo:  "+ novo);
			System.out.println("\t dado:"+novo.dado);
			// Conectando os 2 NÓS
			lista.prox = novo;
//Exercicio1
			NO novo2 = new NO();
			novo2.dado = 3;
			novo2.prox = lista;
			System.out.println("novo2:  "+ novo2);
			System.out.println("\t dado:"+novo2.dado);
			System.out.println("\t novo2.prox: "+ novo2.prox);
//Exercicio2
			lista = novo2;
			System.out.println("lista:  "+ lista);
			
			
//Exercicio3
			System.out.println("Apresentacao da lista encadeada");
			NO aux = lista;
			while (aux!=null) {
				System.out.println("dado: "+ aux.dado);
				aux = aux.prox;
			}
			
		}
	}
}
