package exercicio1;

import java.util.Scanner;

public class Exercicio1 {

	public static void main(String[] args) {
		Scanner le = new Scanner(System.in);
		final int N = 10;
		double saldos[] = new double[N];
		int qtdNeg = 0;
		for (int i = 0; i < N; i++) {
			System.out.print("saldo do cliente[" + i + "]: ");
			saldos[i] = le.nextDouble();
			if (saldos[i] < 0) {
				qtdNeg++;
			}
		}
		System.out.println("Valores de Saldos Positivos");
		for (int i = 0; i < N; i++) {
			if (saldos[i] >= 0) {
				System.out.println("\t R$" + saldos[i]);
			}
		}
		System.out.println("Quantidade de clientes com saldo negativo: "+qtdNeg);
		le.close();

	}

}
