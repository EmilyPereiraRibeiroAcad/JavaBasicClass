package pilhas;

import java.util.ArrayList;

public class PilhaAInt {
	
	int topo;
	ArrayList<Integer> dados = new ArrayList<>();
	
	public void init() {
		topo = 0;
	}

	public boolean isEmpty() {
		return (topo == 0);
	}
	
	public void push(int elem) {
		dados.add(topo, elem);
		topo++;
	}
	public Integer pop() {
		topo--;
		return (dados.remove(topo));
	}

}
