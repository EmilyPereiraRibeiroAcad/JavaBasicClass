package exercicio5;

import java.util.Scanner;

import pilhas.PilhaAInt;

public class Palindromo {

	public static void main(String[] args) {
		Scanner le = new Scanner(System.in);
		int lido[] = new int[6];
		PilhaAInt pilha = new PilhaAInt();
		pilha.init();
		
		System.out.print("Informe digito (0..9): ");
		int digito = le.nextInt();
		int i=0;
		while (digito>=0) {
			lido[i] = digito;
			i++;
			pilha.push(digito);
			System.out.print("Informe digito (0..9): ");
			digito = le.nextInt();
		}
		boolean palindromo = true;
		for (i=0; !pilha.isEmpty() && palindromo ; i++) {
			if (lido[i] != pilha.pop()){
				palindromo = false;
			}
		}
		if (palindromo)
			System.out.println("E' palindromo");
		else
			System.out.println("NAO E' palindromo");
		le.close();
	}

}
