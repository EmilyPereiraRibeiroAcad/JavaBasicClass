package aula;

public class CallStack {

	public static void main(String[] args) {
		System.out.println("Iniciando Main");
		funcaoA();
		System.out.println("Encerrando Main");

	}

	public static void funcaoA() {
		System.out.println("\tIniciando funcao A");
		funcaoB();
		System.out.println("\tEncerrando funcao A");

	}
	public static void funcaoB() {
		System.out.println("\t\tIniciando funcao B");


		System.out.println("\n\t\tEncerrando funcao B");

	}
}
