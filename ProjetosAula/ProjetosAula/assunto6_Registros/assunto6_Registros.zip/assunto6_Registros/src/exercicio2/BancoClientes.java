package exercicio2;

import java.util.Scanner;

public class BancoClientes {

	public static class Cliente {
		String nome, cpf, endereco;
		int conta, ano;
		double saldo;
	}

	public static void main(String[] args) {
		Scanner le = new Scanner(System.in);
		// Declara vetor de objetos cliente da classe Cliente
		Cliente clientes[] = new Cliente[2000];
		int resp = 1;
		int i = 0;
		do {
			//Cria 1 objeto da classe Cliente
			Cliente cliente = new Cliente();
			System.out.print("Nome do cliente: ");
			// leia do teclado o nome do cliente
			cliente.nome = le.nextLine();
			System.out.print("CPF: ");
			// leia do teclado o CPF do cliente
			cliente.cpf = le.nextLine();
			System.out.print("Endereco: ");
			// leia do teclado o endereco do cliente
			cliente.endereco = le.nextLine();
			System.out.print("Numero da conta: ");
			// leia do teclado o numero da conta do cliente
			cliente.conta = le.nextInt();
			System.out.print("Ano de abertura: ");
			// leia do teclado o ano da abertura da conta do cliente
			cliente.ano = le.nextInt();
			System.out.print("Saldo: ");
			// leia do teclado o saldo do cliente
			cliente.saldo = le.nextDouble();
			//Atribui o cliente a posicao i do vetor de clientes
			clientes[i] = cliente;
			i++;
			System.out.print("Cadastrar mais 1 cliente? (1-sim): ");
			resp = le.nextInt();
			le.nextLine();
		} while (resp == 1 && i<2000);
		int numClientes = i;
		int contNeg = 0;
		int cont10 = 0;
		System.out.println("\n\n *********** Clientes com saldo negativo ***********");
		for (i=0;i<numClientes;i++) {
			if (clientes[i].ano <= 2015) {
				cont10++;
			}
			if (clientes[i].saldo<0) {
				contNeg++;
				System.out.println("Nome: " + clientes[i].nome);
				System.out.println("CPF: " + clientes[i].cpf);
				System.out.println("Endereco: " + clientes[i].endereco);
				System.out.println("Numero da conta: " + clientes[i].conta);
				System.out.println("Ano de abertura da conta: " + clientes[i].ano);
				System.out.println("Saldo: R$" + clientes[i].saldo);
			}	
		}
		System.out.println(" ***************************************************");
		System.out.println("Quantidade de clientes com saldo negativo: "+contNeg);
		System.out.println("Quantidade de clientes com mais de 10 anos de relacionamento: "+cont10);
		
		String cpf;
		do {
			System.out.print("Informe cpf para procurar ou escreva sair: ");
			cpf = le.next();
			int pos = -1;
			for (i=0; i<numClientes && pos==-1; i++) {
				if (cpf.compareTo(clientes[i].cpf)==0) {
					pos = i;
				}
			}
			if (pos==-1)
				System.out.println("CPF nao encontrado");
			else {
				System.out.println("Nome: " + clientes[pos].nome);
				System.out.println("CPF: " + clientes[pos].cpf);
				System.out.println("Endereco: " + clientes[pos].endereco);
				System.out.println("Numero da conta: " + clientes[pos].conta);
				System.out.println("Ano de abertura da conta: " + clientes[pos].ano);
				System.out.println("Saldo: R$" + clientes[pos].saldo);
			}	
		}while(cpf.compareToIgnoreCase("sair")!=0);
		le.close();
	}

}
